var sql = require('mssql'); 
var async = require('async');

function WineDb(sqlConfig) {
  this.sqlConfig = sqlConfig;
  this.sql = sql;
  this.connection = null;
}

module.exports = WineDb;


WineDb.prototype = {
    
    find: function (querySpec, callback) {
        var self = this;
        
        self.connection  = new self.sql.Connection(self.sqlConfig, function(err){
            if (err != null){
                callback(err);
                return;
            }
            
            self.executeRequest(querySpec, callback);
        });
  },
    
    executeRequest : function(querySpec, callback) {
        var self = this;
        var request = new self.sql.Request(self.connection);

        if(querySpec.parameters) {
            async.forEach(querySpec.parameters, function(parameter, callback){
                var typid = parameter.type;
                if(typid)
                    request.input(parameter.name, typid, parameter.value);
                else
                    request.input(parameter.name, parameter.value);
            })
        }
 
        request.query(querySpec.query).then(function(recordset){
            callback(null, recordset);
        }).catch(function (err) {
            callback(err);
        });
    }
};