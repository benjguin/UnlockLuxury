var express = require('express');
var Wines = require('./routes/wines');
var WineDb = require('./models/wineDb');
var sql = require('mssql'); 
 
var app = express();



var sqlConfig = {
    user: 'spertus',
    password: 'azerty31$',
    server: 't9okmkvd4j.database.windows.net',
    database: 'UnlockLuxuryDB',

    options: {
        encrypt: true // Use this if you're on Windows Azure
    }
}

// Declare the wineDb helper
var wineDb = new WineDb(sqlConfig);

// Declare the wineList helper
var wines = new Wines(wineDb);



app.get('/wines', wines.showWines.bind(wines));

var port = process.env.PORT || 3000;
app.listen(port);

console.log('Listening on port ' + port + '...');

