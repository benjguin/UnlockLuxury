﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using ulwebserver.Models;

namespace ulwebserver.Controllers
{
    public class WinesController : ApiController
    {
        private UnlockLuxuryContext db = new UnlockLuxuryContext();

        // GET: api/Wines
        public IQueryable<Wine> GetWines()
        {
            return db.Wines;
        }

        // GET: api/Wines/5
        [ResponseType(typeof(Wine))]
        public async Task<IHttpActionResult> GetWine(string id)
        {
            Wine wine = await db.Wines.FindAsync(id);
            if (wine == null)
            {
                return NotFound();
            }

            return Ok(wine);
        }

        // PUT: api/Wines/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutWine(string id, Wine wine)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != wine.Id)
            {
                return BadRequest();
            }

            db.Entry(wine).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!WineExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Wines
        [ResponseType(typeof(Wine))]
        public async Task<IHttpActionResult> PostWine(Wine wine)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Wines.Add(wine);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (WineExists(wine.Id))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = wine.Id }, wine);
        }

        // DELETE: api/Wines/5
        [ResponseType(typeof(Wine))]
        public async Task<IHttpActionResult> DeleteWine(string id)
        {
            Wine wine = await db.Wines.FindAsync(id);
            if (wine == null)
            {
                return NotFound();
            }

            db.Wines.Remove(wine);
            await db.SaveChangesAsync();

            return Ok(wine);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool WineExists(string id)
        {
            return db.Wines.Count(e => e.Id == id) > 0;
        }
    }
}