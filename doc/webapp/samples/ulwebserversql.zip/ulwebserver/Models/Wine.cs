﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ulwebserver.Models
{
    public class Wine
    {
        public String Id { get; set; }
        public int Year { get; set; }

        public String Grapes { get; set; }

        public String Country { get; set; }

        public String Description { get; set; }
    }
}
