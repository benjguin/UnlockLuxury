﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using ulwebserver.Models;

namespace ulwebserver.Controllers
{
    public class WinesController : ApiController
    {
        private UnlockLuxuryContext db;

        public WinesController()
        {
            db = new UnlockLuxuryContext("UnlockLuxuryDatabase", "Wines");
            db.Initialize().Wait();
        }

        // GET: api/Wines
        public IQueryable<Wine> GetWines()
        {
            return db.Get<Wine>().AsQueryable();
        }

        // GET: api/Wines/5
        [ResponseType(typeof(Wine))]
        public async Task<IHttpActionResult> GetWine(string id)
        {
            return await Task.Run<IHttpActionResult>(() =>
             {
                 Wine wine = db.Get<Wine>().Where(w => w.Id == id).AsEnumerable().FirstOrDefault();

                 if (wine == null)
                     return NotFound();

                 return Ok(wine);

             });
        }
    }
}