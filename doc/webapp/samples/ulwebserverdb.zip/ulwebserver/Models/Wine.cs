﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ulwebserver.Models
{
    public class Wine
    {
        [JsonProperty(PropertyName = "id")]
        public String Id { get; set; }
        [JsonProperty(PropertyName = "year")]
        public int Year { get; set; }

        [JsonProperty(PropertyName = "grapes")]
        public String Grapes { get; set; }

        [JsonProperty(PropertyName = "country")]
        public String Country { get; set; }

        [JsonProperty(PropertyName = "description")]
        public String Description { get; set; }
    }
}
