﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace ulwebserver.Models
{
    //https://github.com/rleopold/DocDbWebApi/tree/master/DocDbWebApi/Data 

    public class UnlockLuxuryContext
    {

        private string endpointUrl;
        private string authorizationKey;
        private DocumentCollection collection;
        private DocumentClient client;
        private Database database;

        private string collectionId;
        private string databaseId;

        public DocumentClient Client
        {
            get
            {
                return client;
            }
        }


        public IOrderedQueryable<T> Get<T>()
        {
            return Client.CreateDocumentQuery<T>(new Uri(collection.SelfLink, UriKind.Relative));
        }

        public UnlockLuxuryContext(string databaseId, string collectionId)
        {
            endpointUrl = ConfigurationManager.AppSettings["EndpointUrl"];
            authorizationKey = ConfigurationManager.AppSettings["AuthorizationKey"];
            this.collectionId = collectionId;
            this.databaseId = databaseId;

            client = new DocumentClient(new Uri(endpointUrl), authorizationKey);
        }

        public async Task<bool> Initialize()
        {
            try
            {
                if (database == null)
                {
                    database = client.CreateDatabaseQuery()
                        .Where(d => d.Id == databaseId)
                        .AsEnumerable()
                        .FirstOrDefault();

                    if (database == null)
                        database = await client.CreateDatabaseAsync(new Database { Id = databaseId });
                }

                collection = client.CreateDocumentCollectionQuery(new Uri(database.SelfLink, UriKind.Relative))
                  .Where(c => c.Id == collectionId)
                  .AsEnumerable()
                  .FirstOrDefault();

                if (collection == null)
                {
                    collection = await client.CreateDocumentCollectionAsync(database.SelfLink, new DocumentCollection { Id = collectionId });
                }


                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                return false;
            }

        }

        /// <summary>
        /// Get a document from the collection 
        /// </summary>
        /// <param name="id">the id of the document</param>
        /// <returns></returns>
        private Document GetDocument(string id)
        {
            return client.CreateDocumentQuery<Document>(new Uri(collection.DocumentsLink, UriKind.Relative))
                        .Where(d => d.Id == id)
                        .AsEnumerable()
                        .FirstOrDefault();
        }

    }
}
