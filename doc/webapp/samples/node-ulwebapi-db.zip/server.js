var express = require('express');
var Wines = require('./routes/wines');
var WineDb = require('./models/wineDb');
 
var app = express();

var DocumentClient = require('documentdb').DocumentClient;

var host = "https://ulseb.documents.azure.com:443/"; // Add your endpoint
var masterKey = "PjlDnmWpcryKByCSP7Q-------truncated--------w9ymKF7g==";  // Add the massterkey of the endpoint

var client = new DocumentClient(host, {masterKey: masterKey});

var databaseDefinition = { id: "UnlockLuxuryDatabase" };
var collectionDefinition = { id: "Wines" };

// Declare the wineDb helper
var wineDb = new WineDb(client, databaseDefinition, collectionDefinition);
// init
wineDb.init();

// Declare the wineList helper
var wines = new Wines(wineDb);

app.get('/wines', wines.showWines.bind(wines));

var port = process.env.PORT || 3000;
app.listen(port);

console.log('Listening on port ' + port + '...');

