var DocumentDBClient = require('documentdb').DocumentClient;
var async = require('async');

function WineList(WineDB) {
  this.wineDb = WineDB;
}

module.exports = WineList;

WineList.prototype={
  
  showWines: function(req, res){
      var self = this;
      
      // var querySpec = {
      //   query : 'SELECT * from Wines w where w.id=@id',
      //   parameters :[{ name:'@id', value:'1234'  }]
      // };
      
      var querySpec = {
        query : 'SELECT * from Wines',
      };

      self.wineDb.find(querySpec, function(err, items)
      {
          if (err) {
                throw (err);
            }

            res.send(items); 
      });
      
  }
    
};

